Installation:

	Download the repo and then double click on index.html to open it.

Overview:

	This app shows a map of Washington D.C. Shows some locations one should visit if they ever get the chance. Some are historical, some are fun, and some are just cool things to look at. Clicking on the markers or the list on the side will show it's name, it's address, and some info from Wikipedia.